<?php

$lang['upload_userfile_not_set'] = "Жіберілген  userfile айнымалыны табу мүмкін емес.";
$lang['upload_file_exceeds_limit'] = "Жіберілетін файл сіздің PHP configuration file рұқсат етілген өлшемінен артық.";
$lang['upload_file_exceeds_form_limit'] = "Жіберілетін файл жіберу формасының рұқсат етілген өлшемінен артық.";
$lang['upload_file_partial'] = "Файл жартылай жүктелді.";
$lang['upload_no_temp_directory'] = "Уақытша папка жоғалды.";
$lang['upload_unable_to_write_file'] = "Файлды дискке жазу мүмкін емес.";
$lang['upload_stopped_by_extension'] = "Файлдың жүктелуі  кеңейтілімге байланысты тоқтатылды.";
$lang['upload_no_file_selected'] = "Сіз жіберілетін файлды таңдаған жоқсыз";
$lang['upload_invalid_filetype'] = "Сіз жүктеп жатқан файл түріне рұқсат етілмеген.";
$lang['upload_invalid_filesize'] = "Сіз жүктеп жатқан файл рұқсат етілген өлшемдерден асып кетеді.";
$lang['upload_invalid_dimensions'] = "Сіз жүктеп жатқан суреттің ені немесе ұзындығы рұқсат етілген өлшемдерден артық.";
$lang['upload_destination_error'] = "Файлды уақытша папкадан тұрақты папкаға орналастыруда қателік пайда болды.";
$lang['upload_no_filepath'] = "Жүктеу жолы дұрыс емес.";
$lang['upload_no_file_types'] = "Сіз файлдардың арнайы түрлерін көрсетпедіңіз.";
$lang['upload_bad_filename'] = "Мұндай файл атауы серверде бар.";
$lang['upload_not_writable'] = "Жүктелу жүзеге асырылатын директория жазба үшін жабық.";

/* End of file upload_lang.php */
