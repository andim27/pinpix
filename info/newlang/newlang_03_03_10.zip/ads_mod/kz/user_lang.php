<?php
$lang['user_members_title'] = "Қатысушылар";

$lang['user_about']     = "Өзіңіз туралы";
$lang['user_interests'] = "Менің қызығушылықтарым";
$lang['user_login']     = "Пайдаланушының аты";
$lang['user_email']     = "E-mail";
$lang['user_information']= "Пайдаланушы туралы мәлімет";
$lang['user_birthdate'] = "Туған күніңіз";
$lang['user_country']   = "Мемлекет";
$lang['user_region']    = "Аймақ";
$lang['user_city']      = "Қала";
$lang['user_birth_day']   = "Күні";
$lang['user_birth_month'] = "Айы";
$lang['user_birth_year']  = "Жылы";
$lang['user_about_title'] = "Өзіңіз туралы қысқаша мәлімет";
$lang['user_interest_title'] = "Талғамдар";
$lang['user_registration_date'] = "Тіркелу мерзімі";
$lang['user_control_block'] = "Профильді басқару болгы";
$lang['user_save']       = "Сақтау";
$lang['user_attributes'] = "Атрибуттар";
$lang['user_edit']       = "Түзету";
$lang['user_change_psw'] = "Парольді өзгерту";
$lang['user_new_psw']    = "Жаңа пароль";
$lang['user_confirm_psw']= "Парольді нақтылау";

$lang['user_save_psw']   = "Парольді сақтау";
$lang['not_fill']        = "Толтырылмаған";
$lang['user_rating']     = "Сіздің рейтингтік көрсеткіштеріңіз";
$lang['error_activation_process'] = "Активация үрдісі барысында қателіктер туды. $admin_email мекен-жайындағы сайт әкімшілігімен байланысуыңызды сұраймыз.";
$lang['error_activation_link'] = "Активация сілтемесі дұрыс емес. Біз жіберген хаттағы активация сілтемесін пайдалануыңызды сұраймыз.";
$lang['error_activation_info'] = "Активация мәліметтері дұрыс емес. Егер сіз өз аккаунтыңызды іске қоссаңыз, бізге жіберген email мен пароль сәйкестігін тексеріңіз немесе $admin_email мекен-жайындағы сайт әкімшілігімен байланысыңыз";
