<?php
	$lang['user_members_title'] = "Members";

	$lang['user_about']	= "User about";
	$lang['user_interests'] = "My interests";
	$lang['user_login'] 	= "My login";
	$lang['user_email'] 	= "My email";
	$lang['user_information']= "User information";
	$lang['user_birthdate'] = "Birthday";
	$lang['user_country']	= "Country";
	$lang['user_region'] 	= "Region";
	$lang['user_city'] 	= "City";
	$lang['user_registration_date'] = "Date of registration";
	$lang['user_control_block'] = "Control profile block";
	$lang['user_save'] 	 = "Save";
	$lang['user_attributes'] = "Attributes";
	$lang['user_edit'] 	     = "Edit";
	$lang['user_change_psw'] = "Change password";
	$lang['user_new_psw'] 	 = "New password";
	$lang['user_confirm_psw']= "Confirm password";

	$lang['user_save_psw']	 = "Save password";
	$lang['not_fill'] 	     = "Not filled";
	$lang['user_rating']	 = "Rating position";