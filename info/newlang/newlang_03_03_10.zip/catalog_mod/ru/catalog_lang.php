<?php
$ci = &get_instance();
$admin_email = $ci->config->item('admin_email');
// Retrieve a config item named site_name contained within the blog_settings array
$site_title = $ci->config->item('site_name', 'blog_settings');

//$lang[''] = "";  //for copying

$lang['category'] = "Категория";

$lang['cat_name_field'] = "Название категории:";
$lang['cat_desc_field'] = "Описание категории:";
$lang['save'] = "Сохранить категорию";

$lang['error_data_saving'] = "Проблема с сохранением данных. Попробуйте отправить позже или свяжитесь с администратором сайта по адресу $admin_email";

/* End of file catalog_lang.php */
