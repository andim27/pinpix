<?php
        $lang['view_private'] = "Личный";
        $lang['view_registered'] = "Зарегистрированые";
        $lang['view_public'] = "Всем";

        $lang['gallery'] = "Альбомы";
        $lang['album_declined'] = "Удаленные альбомы";
        $lang['album_edit_title'] = "Редактировать альбом";
        $lang['album_new'] = "Новый альбом";
        
        $lang['album_title'] = "Название";
        $lang['album_desc'] = "Описание";
        $lang['album_cat'] = "Раздел";
        $lang['album_rule'] = "Разрешен просмотр";
        $lang['album_erotic'] = "Эротика";
        $lang['album_password'] = "Пароль на альбом";
        $lang['photo_password'] = "Пароль на фото";
        $lang['photo_password_confirm'] = "Подтверждение пароля";

        $lang['album_not_photos'] = "Альбом пуст";
        $lang['album_add_photo'] = "Добавить фото";
        $lang['album_add_abum'] = "Добавить альбом";
        $lang['album_delete_message'] = "Когда Вы удалите альбом,&nbsp;все фотографии из него также будут удалены. Продолжить?";
        $lang['album_of_photos'] = "Фото";
        $lang['album_of_rate'] = "Рейтинг";
        $lang['album_of_comments'] = "Комментариев";
        $lang['album_of_created'] = "Создан";

        $lang['photo_of_album'] = "Альбом";
        $lang['albums'] = "Альбомов";
        $lang['photo_of_catalog'] = "Разделы каталога";
        $lang['photo_of_tags'] = "Теги";
        $lang['photo_of_rating'] = "Рейтинг";
        $lang['photo_of_views'] = "Просмотров";
        $lang['photo_of_owner'] = "Владелец фото";
        $lang['photo_of_date_added'] = "Дата добавления";
        
        $lang['photo_code_for_copy'] = "Код для копирования";  
        $lang['photo_code_link'] = "Ссылка (URL)";
        $lang['photo_code_empbed'] = "Для вставки на страницу (Embed)";

        $lang['photo_prop']="Свойство фото!";
        $lang['photo_name']="Название фото!";
        $lang['photo_updated']="Фото изменено!";
        $lang['photo_in_comp']="Фото принято на конкурс!";
        $lang['photo_in_main']="Фото выставленно главным!";
        $lang['photo_to_comp']="Отправить на конкурс";
        $lang['photo_main_album']="Сделать главной для альбома";
        $lang['photo_main']="Сделать главной";
        $lang['photo_attan']="Внимание!";
        $lang['photo_attan_mes']="На один конкурс можно присылать не больше пяти фото!";
        //      -- moderation_state ---
        $lang['album_mod_state_new'] = "новый";
        $lang['album_mod_state_approved'] = "подтверждено";
        $lang['album_mod_state_featured'] = "функционально";
        $lang['album_mod_state_declined'] = "отклонено";
        $lang['error_album_is_exist'] = 'Альбом с таким именем уже существует';
        
        $lang['photo_is_erotic'] = "Эротика";

        $lang['error_empty'] = "Фотографии по Вашему запросу не найдены";
        $lang['error_empty_request'] = "Запрос пуст";
        $lang['error_empty_user'] = "Не найдена информация об авторе фото";
        $lang['error_forbidden'] ='Изображение запрещено для просмотра';
        
        $lang['error_create_upload_dir'] = "Невозможно создать дирректорию для загрузки!";
        $lang['error_title_not_enter'] = "Вы должны ввести название альбома!";
        $lang['error_desc_not_enter'] = "Вы должны ввести описание альбома!";
        $lang['error_category_not_selected'] = "Категория не выбрана!";
        
        $lang['error_photo_is_exist'] = 'Фото с таким именем уже существует';
        $lang['code_link_txt'] ='';
// error
//      You have to be logged in to upload photos
//      You need to enter a title for you photo.
//      There is already a photo called, you are going to have to choose another name.
//      You need to enter a Photo Description.
//      Please enter some tags that describe your photo.
        
//      $lang['error_filesize_file'] = "The filesize of the photo you are trying to upload is too large";
//      $lang['error_invalid_file'] = "You must upload a valid image file";
//      $lang['error_empty_file'] = "File is empty. You need to upload valid file";
        $lang['give_rate_txt']='Дать рейтинг';
        $lang['stick_pin_txt']='Воткнуть Pin';

        // -- voting ---
        $lang['send_vote_msg']     ="Передаю Ваш голос...";
        $lang['repeat_vote_msg']   ="Повторное голосование запрещено!";
        $lang['remember_vote_msg'] ="Ваш голос защитан!";
        $lang['vote_btn_msg']      ="Голосовать!";
        $lang['voting']            ="Голосование:";
        $lang['avg_title']         ="Средний бал:";
        $lang['login_only']        ="Голосовать могут только зарегистрированные пользователи!";  


        $lang['comp_how'] = "Как принять участие?";
        $lang['comp_how_rule_first'] = "Зарегистрируйтесь на pinpix, если Вы еще этого не сделали";
        $lang['comp_how_rule_second'] = "Загрузите в свой альбом фото";
        $lang['comp_how_rule_third'] = "В свойствах фото выберите конкурс в котором Вы хотиту участвовать";
        $lang['comp_how_rule_forth'] = "Теперь Вы возможный победитель!";

        $lang['empty_cathegory']="В данной категории еще нет альбомов";
        $lang['enter_pwd'] = "Фотография защищена паролем. Пожалуйста, введите пароль для просмотра фотографии: ";
        $lang['enter_alb_pwd'] = "Альбом защищен паролем. Пожалуйста, введите пароль для просмотра альбома: ";

        $lang['error_heading']  = "Возникла ошибкa: ";
        $lang['error_view_register']  = "Для просмотра фотографии необходимо зарегистрироваться.";
        $lang['error_view_erotic']  = "Запрещено до 18 лет.";

        $lang['download']  = "Доступные разрешение";


