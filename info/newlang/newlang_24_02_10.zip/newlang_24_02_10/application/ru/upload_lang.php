﻿<?php

$lang['upload_userfile_not_set'] = "upload_userfile_not_set.";
$lang['upload_file_exceeds_limit'] = "upload_file_exceeds_limit";
$lang['upload_file_partial'] = "upload_file_partial";
$lang['upload_no_file_selected'] = "upload_no_file_selected";
$lang['upload_invalid_filetype'] = "upload_invalid_filetype";
$lang['upload_invalid_filesize'] = "upload_invalid_filesize.";
$lang['upload_invalid_dimensions'] = "upload_invalid_dimensions";
$lang['upload_destination_error'] = "upload_destination_error";
$lang['upload_no_filepath'] = "upload_no_filepath.";
$lang['upload_no_file_types'] = "upload_no_file_types";
$lang['upload_bad_filename'] = "upload_bad_filename";
$lang['upload_not_writable'] = "upload_not_writable";

