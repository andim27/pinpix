<?php
$ci = &get_instance();
$admin_email = $ci->config->item('admin_email');
// Retrieve a config item named site_name contained within the blog_settings array
$site_title = $ci->config->item('site_name', 'blog_settings');

//$lang[''] = "";  //for copying

$lang['pages'] = "Страницы: ";

$lang['search'] = "поиск";

$lang['mod_state_new'] = 'Новые';
$lang['mod_state_approved'] = 'Утвержденные';
$lang['mod_state_featured'] = 'Отмеченные';
$lang['mod_state_declined'] = 'Отклоненные';

$lang['registration'] = "Регистрация";
$lang['reg_step_1'] = "Шаг1: введите свое имя username и кореектный адрес email";
$lang['username_field'] = "Введите Ваше имя:";
$lang['email_field'] = "Адрес Email:";
$lang['reg_step_2'] = "Шаг 2: Активация отправки Email";

$lang['remember_sent'] = "Пожалуйста, проверьте свою почту на предмет пароля, который мы Вам отправили";

$lang['activation_sent'] = "Пожалуйста, проверьте свою почту на предмет активационного письма, которое мы Вам отправили, и перейдите по ссылке, для того, чтобы подтвердить регистрацию.";
$lang['reg_step_3'] = "Шаг 3: Успешная активация";
$lang['start_using_account'] = "Ваш аккаунт активен и Вы можете начинать его использование.
  Пожалуйста, проверьте Ваш Email на предмет информации о доступе,&nbsp;которую мы Вам отправили.
  Не забывайте безопасно хранить Вашу информацию о доступе.";
$lang['collect_information_for_profile'] = "Сейчас мы хотим собрать некоторую дополнительную информацию по Вашему профилю на нашем сайте.";

$lang['error_login_empty']  = "Поле 'Имя пользователя' не заполеннно!";
$lang['error_login_wrong']  = "Неверное имя пользователя или пароль!";
$lang['error_login_used']  = "Это имя уже используется. Пожалуйста, выберите другое.";

$lang['login_input']  = "Введите имя username";
$lang['email_input']  = "Введите email-адрес";
$lang['error_email_format']  = "Неверный формат еmail-адреса";
$lang['error_email_used']  = "Такой email-адрес уже используется. Возможно Вы <a href='/forgot-password'>забыли Ваш пароль?</a>";
$lang['banned']  = "Имя пользователя заблокировано!";
$lang['not_activated']  = "Имя пользователя еще не активировано! Пожалуйста, перейдите по ссылке в письме активации, высланное на указанный email-адрес";
$lang['confirm_reg'] = "Подтвердите свою регистрацию на $site_title";
$lang['error_data_saving'] = "Проблема с сохранением Ваших данных. Пожалуйста, попробуйте позже или свяжитесь с администратором сайта по $admin_email";
$lang['error_activation_link'] = "Неверная ссылка для активации. Пожалуйста, используйте ссылку для активации из письма, которое мы Вам прислали";
$lang['error_activation_info'] = "Неверная активационная информация. Если Вы уже активировали Ваш аккаунт, cпроверьте email и пароль, которые Вы нам отправили, или свяжитесь с администратором сайта по  $admin_email";
$lang['reg_success'] = "Регистрация на $site_title прошла успешно";

$lang['error_activation_process'] = "Во время процесса активации возникли ошибки. Пожалуйста, свяжитесь с администратором сайта по $admin_email";

$lang['email_changed_adm'] = "Ваш email-адрес изменен администратором";
$lang['email_changed'] = "Ваш email-адрес изменен";
$lang['email_change_requested'] = "Запрошенный email-адрес изменен";
$lang['confirm_email_sent'] = "Информация для подтверждения отправленна на Ваш новый адрес.  Пожалуйста, используйте активационную ссылку из письма, которое мы Вам прислали, для подтверждения изменений.";
$lang['error_confirmation_link'] = "Неверная ссылка для подтверждения. Пожалуйста, используйте активационную ссылку из письма, которое мы Вам прислали";
$lang['error_confirmation_info'] = "Неверная информация для подтверждения. Возможно,&nbsp;Вы уже подтвердили изменения?";
$lang['confirm_passw'] = "Пожалуйста,подтвердите пароль";
$lang['error_passw_mismatch'] = "Утерян пароль";
$lang['passw_changed'] = "Пароль изменен";
$lang['access_info_changed'] = "Изменена информация для доступа";
$lang['error_user_not_found'] = "Пользователь с таким email-адресом не найден";
$lang['error_security_question'] = "Вы неверно указали секретный вопрос для ввода пароля. Пожалуйста, свяжитесь с администратором сайта по $admin_email";
$lang['error_answer'] = "Ответ неверный";
$lang['passw_reset'] = "Ваш пароль изменен. Пожалуйста,&nbsp;проверьте почту и используйте новый пароль для доступа.";

$lang['login'] = 'Логин ';
$lang['password'] = 'Пароль ';
$lang['error_auth']  = "Неверный логин или пароль!";

$lang['forgot_password'] = 'Забыли пароль?';
$lang['register'] = 'Регистрация';


$lang['male'] = "Мужской";
$lang['female'] = "Женский";

$lang['name'] = 'Имя';
$lang['description'] = 'Краткое описание';

$lang['category_tags'] = 'Ключевые слова категории';

$lang['to_delete'] = "удалить";
$lang['to_edit'] = "редактировать";
$lang['to_add'] = "добавить";
$lang['date'] = "Дата";
$lang['rate'] = "Рейтинг";

$lang['competitions'] = "Конкурсы";
$lang['comp_sort_by'] = "Сортировка";
$lang['comp_sort_by_date'] = "Самые последние";
$lang['comp_sort_by_rate'] = "Самые популярные";
$lang['comp_sort_by_name'] = "A-Я";
$lang['comp_sort_by_relevance'] = "Соответствие";
$lang['faq'] = "FAQ";
$lang['contacts'] = "Контакты";
$lang['help'] = "Помощь";
$lang['exit'] = "Выход";
$lang['enter'] = "Вход";
$lang['categories'] = "Разделы";

$lang['search'] = "Поиск";
$lang['search_key_word'] = "Ключевые слова";
$lang['search_in_section'] = "Поиск в разделе";

$lang['user_all_photos'] = "Все фото подряд";
$lang['user_comments'] = "Комментариев";
$lang['user_views'] = "Просмотров";
$lang['user_albums'] = "Альбомов";
$lang['user_photos'] = "Фото";

$lang['user_photo_properties'] = "Свойства фото";
$lang['user_photo_title'] = "Название фото";
$lang['user_photo_category'] = "Раздел";
$lang['user_photo_album'] = "Альбом";
$lang['user_photo_competitions'] = "Отправить на конкурс";
$lang['user_photo_album_main'] = "Сделать главной для альбома";
$lang['user_photo_page_main'] = "Показать в заголовке главной страницы";
$lang['user_photo_upload'] = "Загрузить фото";
$lang['user_photo_file'] = "Файл";
$lang['user_photo_erotic'] = "Эротика";
$lang['user_photo_description'] = "Описание";
$lang['user_photo_allowed'] = "Просмотр для";
$lang['user_photo_bulk_upload'] = "Для массовой загрузки фотографий, просто упакуйте их на своем компьютере в любой из архивов .ZIP, .RAR";
$lang['user_photo_5_upload'] = "На конкурс можно загружать до 5 фотографий";
$lang['user_photo_interests'] = "Мои интересы";
$lang['user_photo_about'] = "Немного о себе";
$lang['user_photo_email'] = "e-mail:";
$lang['user_photo_contacts'] = "Мои контакты";
$lang['user_photo_profile'] = "Профиль";

$lang['user_photo_uploaded_types'] = 'Все файлы рисунков';
$lang['user_photo_uploaded_text'] = 'Выбрать';

$lang['page_not_found'] = "<strong><em>404</em> Страница не найдена</strong>";
$lang['file_not_found'] = "<strong><em>404</em> Фото не найдено</strong>";

$lang['photo_deleted'] = "<strong> Фото было удалено </strong>";
$lang['photo_declined'] = "<strong> Фото было отклонено для показа</strong>";
$lang['photo_not_approved'] = "<strong> Фото еще не прошло модерацию</strong>";
$lang['abum_not_approved'] = "<strong> Альбом еще не прошел модерацию</strong>";
$lang['photo_not_good'] = "<strong> Качество фото недостаточно хорошее</strong>";

$lang['deleted_photos_albums'] = "Удаленные фото и альбомы";

$lang['js_label_FileEmpty'] = "Не выбран файл для загрузки";
$lang['js_label_PasswordEmpty'] = "Необходимо заполнить пароль";
$lang['js_label_ConfirmationEmpty'] = "Необходимо заполнить подтверждение";
$lang['js_label_PwsConfDifferent'] = "Введённые пароль и подтверждение не совпадают";
$lang['js_label_PwsConfDifferent_cur'] = "Введённые пароль и текущий пароль не совпадают";
$lang['js_label_ImgSubmitFailed'] = "Не удалось загрузить рисунок";
$lang['js_label_EmptyAlbumTitle'] = "У Вас нет альбомов. Необходимо перед загрузкой фото создать альбом";
$lang['js_label_DeleteConfirmation'] = "Вы уверены?";
$lang['js_label_DeleteAlbumConfirmation'] = "Удалить выбранный альбом?";

$lang['js_label_EmptyTitle'] = "Необходимо заполнить название.";
$lang['js_label_NotValidTitle'] = "Название сожержит недопустимые символы";
$lang['js_label_EmptyStartTime'] = "Необходимо заполнить дату начала.";
$lang['js_label_EmptyEndTime'] = "Необходимо заполнить дату конца.";
$lang['js_label_EmptyDescription'] = "Необходимо заполнить описание.";

$lang['deleted_warnung_title'] = "Внимание!";
$lang['deleted_warnung'] = "Удаленные фотографии и альбомы хранятся здесь только 30 дней. Позже они будут удалены из хранилища на сервере постоянно.";

$lang['error_heading']  = "Возникла ошибкa:";
$lang['error_mailing']  = "Возникла ошибкa при отправке информации по почте";
$lang['no_photo']  = "Нет новых фото за последнюю неделю";
$lang['new_photo']  = "Свежие поступления";
$lang['only_for_author']  = "Доступ открыт только для автора фото";
$lang['no_flash'] ="Для успешного отображения <br>flash-элементов на сайте,<br/><a href='http://www.adobe.com/go/getflash/'>необходимо установить<br> flash-проигрыватель</a>";
$lang['welcome']  = "Добро пожаловать! Вы успешно вошли в систему!";
$lang['ok_redirect']  = "Для загрузки работ на конкурс, пройдите по ссылке ";

$lang['work_added']  = " Ваша работа принята на рассмотрение. После проверки администратором, на указанный вами e-mail адрес будет отправлено сообщение о принятии работы на конкурс. ";  
$lang['comp_continue']  = "Если Вы хотите добавить еще одну работу, нажмите на кнопку Продолжить ";

$lang['email_in_use']  = "Этот email уже был указан при регистрации другого аккаунта";  

$lang['remember_me'] = "запомнить меня";
$lang['forget_pwd'] = "Забыли пароль";
$lang['all_albums'] = "Все альбомы";

$lang['New_password'] = "Новый пароль";
$lang['New_password_confirmation'] = "Подтвердите пароль";
$lang['wrong_pwd'] = "Неверный пароль!";

$lang['my_photo'] = "Мои фото";
$lang['my_profile'] = "Мои профиль";
$lang['add_photo'] = "Добавить фото";

$lang['agreement'] = "Соглашение";
$lang['command'] = "Команда";
$lang['footer_text'] = "Натуральный логарифм, в первом приближении, оправдывает определитель системы линейных уравнений, дальнейшие выкладки оставим студентам в качестве несложной домашней работы. Можно предположить, что линейное уравнение отображает скачок функции, что известно даже школьникам. Отсюда естественно следует, что открытое множество оправдывает стремящийся полином, таким образом сбылась мечта идиота - утверждение полностью доказано. Прямоугольная матрица трансформирует предел последовательности, явно демонстрируя всю чушь вышесказанного.";
$lang['emailinuse'] = "Этот Email уже используется";

$lang['upgrade_browser'] = "Сайт не работает корректно в браузере Интернет Эксплорер версии 6. <br> Обновите свой браузер до более высокой версии или используйте браузеры  Firefox, Opera, Safari, Chrome.";
$lang['error_heading'] = "Возникла ошибка! ";

$lang['lot_of_photos'] = "Запрещено загружать более 5-ти фото на конкурс! ";
$lang['erotic_banned'] = "Фото из данной категории разрешается просматривать только зарегистрированным пользователям, достигшим 18 лет";

	$lang['comp_openall'] = "Раскрыть все";
	$lang['comp_closeall'] = "Скрыть все";
	
$lang['upload_warn'] = "Идет загрузка фото, не обновляйте страницу до завершения загрузки!";

$lang['bibb_password'] = "Пароль";
$lang['bibb_nik'] = "Ник";
$lang['bibb_email']= "Мой e-mail";
$lang['bibb_password_confirm']= "Подтвердить пароль ";
/*
$security_question[1] = "What is your 1st pet's name?";
$security_question[2] = "What is your favourite movie?";
$security_question[3] = "What is your favourite band?";
*/