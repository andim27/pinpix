<?php
$ci = &get_instance();
$admin_email = $ci->config->item('admin_email');
// Retrieve a config item named site_name contained within the blog_settings array
$site_title = $ci->config->item('site_name', 'blog_settings');

//$lang[''] = "";  //for copying

$lang['pages'] = "Парақтар: ";

$lang['search'] = "іздеу";

$lang['mod_state_new'] = 'Жаңа';
$lang['mod_state_approved'] = 'Бекітілгендер';
$lang['mod_state_featured'] = 'Белгіленгендер';
$lang['mod_state_declined'] = 'Қабылданбағандар';

$lang['registration'] = "қабылданбағандар";
$lang['reg_step_1'] = "Қадам 1: username өз есіміңізді және дұрыс email мекен-жайыңызды енгізіңіз";
$lang['username_field'] = "Өз есіміңізді енгізіңіз:";
$lang['email_field'] = "Email мекен-жайыңыз:";
$lang['reg_step_2'] = "Қадам 2: email-ді жіберу активациясы";

$lang['remember_sent'] = "Өз поштаңызға біз жіберген парольдің келу-келмеуін тексеруіңізді сұраймыз";

$lang['activation_sent'] = "Өз поштаңызға біз жіберген активация хатының келу-келмеуін тексеруіңізді сұраймыз және тіркелуді нақтылау үшін сілтеме бойынша әрекет етіңіз.";
$lang['reg_step_3'] = "Қадам 3: Сәтті активация";
$lang['start_using_account'] = "Сіздің аккаунтыңыз іске қосылды, енді оны пайдалана беруіңізге болады.
  Өз email-ыңыздан біз жіберген қолжетімділік ақпаратының келу-келмеуін тексеруіңізді сұраймыз.
  Қолжетімділік туралы өз мәліметтеріңіздің қауіпсіздігін қамтамасыз етуді ұмытпаңыз.";
$lang['collect_information_for_profile'] = "Қазір біз Сіздің профиліңіз туралы өз сайтымыздан қосымша ақпарат жинамақпыз.";

$lang['error_login_empty']  = "Логин или пуст!";
$lang['error_login_wrong']  = "Неверный логин или пароль!";
$lang['error_login_used']  = "Мұндай ат қолданыста бар. Басқасын таңдауыңызды сұраймыз.";

$lang['login_input']  = "Введите имя пользователя";
$lang['email_input']  = "Email-ыңызды енгізіңіз";
$lang['error_email_format']  = "Email форматы дұрыс емес";
$lang['error_email_used']  = "Такой email-адрес уже используется. Возможно Вы <a href='/forgot-password'>забыли Ваш пароль?</a>";
$lang['banned']  = "Имя пользователя заблокировано!";
$lang['not_activated']  = "Имя пользователя еще не активировано! Пожалуйста, перейдите по ссылке в письме активации, высланное на указанный email-адрес";
$lang['confirm_reg'] = "$site_title сайтындағы өз тіркелуіңізді нақтылаңыз";
$lang['error_data_saving'] = "Сіздің мәліметтеріңізді сақтауда қателік бар. Кейінірек байқап көріңіз немесе $admin_email мекен-жайындағы сайт әкімшілігімен байланысыңыз";
$lang['error_activation_link'] = "Неверная активационная ссылка. Пожалуйста, используйте активационную ссылку из письма, которое мы Вам прислали";
$lang['error_activation_info'] = "Неверная активационная информация. Если Вы уже активировали Ваш аккаунт, cпроверьте email и пароль, которые Вы нам отправили, или свяжитесь с администратором сайта по  $admin_email";
$lang['reg_success'] = "$site_title сайтында тіркелу сәтті аяқталды";

$lang['error_activation_process'] = "Активация үрдісі барысында қателіктер туды. $admin_email мекен-жайындағы сайт әкімшілігімен байланысуыңызды сұраймыз.";

$lang['email_changed_adm'] = "Сіздің email-ыңыз әкімшілік тарапынан өзгертілді";
$lang['email_changed'] = "Сіздің email-ыңыз өзгертілді";
$lang['email_change_requested'] = "Сұралған email өзгертілді";
$lang['confirm_email_sent'] = "Информация для подтверждения отправленна на Ваш новый адрес.  Пожалуйста, используйте активационную ссылку из письма, которое мы Вам прислали, для подтверждения изменений.";
$lang['error_confirmation_link'] = "Неверная ссылка для подтверждения. Пожалуйста, используйте активационную ссылку из письма, которое мы Вам прислали";
$lang['error_confirmation_info'] = "Нақтылауға арналған мәліметтер дұрыс емес. Мүмкін Сіз өзгерістерді нақтылаған шығарсыз?";
$lang['confirm_passw'] = "Праольді нақтылауыңызды сұраймыз";
$lang['error_passw_mismatch'] = "Пароль жоғалып кетті";
$lang['passw_changed'] = "Пароль өзгертілді";
$lang['access_info_changed'] = "Қолжетімділік ақпараттары өзгертілген";
$lang['error_user_not_found'] = "Мұндай email-ді пайдаланушы табылмады";
$lang['error_security_question'] = "Парольді енгізуге арналған құпия сұрақты дұрыс көрсетпедіңіз. $admin_email мекен-жайындағы сайт әкімшілігімен байланысуыңызды сұраймыз";
$lang['error_answer'] = "Жауап дұрыс емес";
$lang['passw_reset'] = "Сіздің пароліңіз өзгертілген. Поштаңызды тексеріңізді және кіру үшін жаңа парольді пайдалануыңызды сұраймыз";

$lang['login'] = 'Ник ';
$lang['password'] = 'Пароль ';
$lang['error_auth']  = "Неверный логин или пароль!";

$lang['forgot_password'] = 'Парольді ұмыттыңыз ба?';
$lang['register'] = 'Тіркелу';


$lang['male'] = "Ер";
$lang['female'] = "Әйел";

$lang['name'] = 'Аты';
$lang['description'] = 'Қысқаша сипаттамасы';

$lang['category_tags'] = 'Топтаманың кілт сөздері';

$lang['to_delete'] = "жою";
$lang['to_edit'] = "түзету";
$lang['to_add'] = "қосу";
$lang['date'] = "Күні";
$lang['rate'] = "Рейтингтік көрсеткіші";

$lang['competitions'] = "Байқаулар";
$lang['comp_sort_by'] = "Топтастыру";
$lang['comp_sort_by_date'] = "Ең соңғылары";
$lang['comp_sort_by_rate'] = "Ең әйгілілері";
$lang['comp_sort_by_name'] = "A-Я";
$lang['comp_sort_by_relevance'] = "Сәйкестік";
$lang['faq'] = "FAQ";
$lang['contacts'] = "Байланыстар";
$lang['help'] = "Көмек";
$lang['exit'] = "Шығу";
$lang['enter'] = "Кіру";
$lang['categories'] = "Бөлімдер";

$lang['search'] = "Іздеу";
$lang['search_key_word'] = "Кілт сөздер";
$lang['search_in_section'] = "Бөлімнен іздеу";

$lang['user_all_photos'] = "Барлық фотосуреттер";
$lang['user_comments'] = "Сын-пікірлер";
$lang['user_views'] = "Көрулер";
$lang['user_albums'] = "Альбомдар";
$lang['user_photos'] = "Фотосурет";

$lang['user_photo_properties'] = "Фотосурет сипаты";
$lang['user_photo_title'] = "Фотосурет атауы";
$lang['user_photo_category'] = "Бөлім";
$lang['user_photo_album'] = "Альбом";
$lang['user_photo_competitions'] = "Байқауға жіберу";
$lang['user_photo_album_main'] = "Альбом үшін басты фотосурет ретінде қолдану";
$lang['user_photo_page_main'] = "Басты парақтың тақырыптық жолағында көрсету";
$lang['user_photo_upload'] = "Фотосурет жүктеу";
$lang['user_photo_file'] = "Файл";
$lang['user_photo_erotic'] = "Эротика";
$lang['user_photo_description'] = "Сипаттамасы";
$lang['user_photo_allowed'] = "Арналған көрулер";
$lang['user_photo_bulk_upload'] = "Бірнеше фотосуреттерді қатар жүктеу үшін оларды өз компьютеріңізде кез келген ZIP, RAR форматтарында мұрағаттаңыз";
$lang['user_photo_5_upload'] = "РќР° РєРѕРЅРєСѓСЂСЃ РјРѕР¶РЅРѕ Р·Р°РіСЂСѓР¶Р°С‚СЊ РґРѕ 5 С„РѕС‚РѕРіСЂР°С„РёР№";
$lang['user_photo_interests'] = "Менің қызығушылықтарым";
$lang['user_photo_about'] = "Қысқаша өзім туралы мәлімет";
$lang['user_photo_email'] = "e-mail:";
$lang['user_photo_contacts'] = "Менің байланыс мәліметтерім";
$lang['user_photo_profile'] = "Профиль";

$lang['user_photo_uploaded_types'] = 'Суреттердің барлық файлдары';
$lang['user_photo_uploaded_text'] = 'Таңдау';

$lang['page_not_found'] = "<strong><em>404</em> Парақ табылмады</strong>";
$lang['file_not_found'] = "<strong><em>404</em> Фотосурет табылмады</strong>";

$lang['photo_deleted'] = "<strong>Фотосурет жойылған</strong>";
$lang['photo_declined'] = "<strong>Фотосурет көрсетілу үшін кейінге қалдырылды</strong>";
$lang['photo_not_approved'] = "<strong>Фотосурет әлі модерациядан өткен жоқ</strong>";
$lang['abum_not_approved'] = "<strong>Альбом әлі модерациядан өткен жоқ</strong>";
$lang['photo_not_good'] = "<strong>Фотосурет сапасы онша жақсы емес</strong>";

$lang['deleted_photos_albums'] = "Жойылған фотосуреттер мен альбомдар";

$lang['js_label_FileEmpty'] = "Жүктеу файлы таңдалған жоқ";
$lang['js_label_PasswordEmpty'] = "Парольді толтыру міндетті болып табылады";
$lang['js_label_ConfirmationEmpty'] = "Нақтылауды толтыру міндетті болып табылады";
$lang['js_label_PwsConfDifferent'] = "Енгізілген пароль мен нақтылау сәйкес келмейді";
$lang['js_label_PwsConfDifferent_cur'] = "Енгізілген пароль  мен текущий пароль сәйкес келмейді";
$lang['js_label_ImgSubmitFailed'] = "Сурет жүктелмеді";
$lang['js_label_EmptyAlbumTitle'] = "Сізде альбом жоқ. Фотосурет жүктемес бұрын альбом құруыңыз керек.";
$lang['js_label_DeleteConfirmation'] = "Сенімдісіз бе?";
$lang['js_label_DeleteAlbumConfirmation'] = "Таңдалған альбомды жою керек пе?";

$lang['js_label_EmptyTitle'] = "Атауын енгізуіңіз керек";
$lang['js_label_NotValidTitle'] = "Атауында рұқсат етілмеген таңбалар бар";
$lang['js_label_EmptyStartTime'] = "Басталу күнін толтыру керек";
$lang['js_label_EmptyEndTime'] = "Аяқталу күнін толтыру керек";
$lang['js_label_EmptyDescription'] = "Сипаттамасын толтыру керек";

$lang['deleted_warnung_title'] = "Назар аударыңыз!";
$lang['deleted_warnung'] = "Жойылған фотосуреттер мен альбомдар мұнда 30 күн ғана сақталады. Кейін олар күндеікті серверіндегі сақтау қорынан да жойылады.";

$lang['error_heading']  = "Қателік бар:";
$lang['error_mailing']  = "Ақпаратты поштамен жіберуде қателік туындады";
$lang['no_photo']  = "Соңғы аптада жаңа фотосуреттер жоқ";
$lang['new_photo']  = "Жаңа түсірілімдер";
$lang['only_for_author']  = "Фотосурет авторы ғана көре алады"; 
$lang['no_flash'] ="РЎР°Р№С‚С‚Р°Т“С‹ flash-СЌР»РµРјРµРЅС‚С‚РµСЂ<br> Р°РЅС‹Т› РєУ©СЂС–РЅСѓС– ТЇС€С–РЅ <br><a href='http://www.adobe.com/go/getflash/'>flash-РѕР№РЅР°Р»С‹РјРґС‹ РѕСЂРЅР°С‚Сѓ Т›Р°Р¶РµС‚</a>";
$lang['welcome']  = "Қош келдіңіз! Сіз жүйеге сәтті кірдіңіз!";  
$lang['ok_redirect']  = "Байқауға жұмыс жүктеу үшін сілтеме бойынша әрекет етіңіз";  

$lang['work_added']  = "спасибо, Ваша работа принята на конкурс ";  
$lang['comp_continue']  = 'Егер Сіз тағы бір жұмыс жүктегіңіз келсе, "Жалғастыру" батырмасын басыңыз';  

$lang['email_in_use']  = "Этот email уже был указан при регистрации другого аккаунта";  

$lang['remember_me'] = "Мені есте сақтау";
$lang['forget_pwd'] = "Парольді ұмыттыңыз ба?";
$lang['all_albums'] = "Барлық альбомдар";

$lang['New_password'] = "Жаңа пароль";
$lang['New_password_confirmation'] = "Парольді нақтылаңыз";
$lang['wrong_pwd'] = "Пароль дұрыс емес!";

$lang['my_photo'] = "Менің фотосуреттерім";
$lang['my_profile'] = "Менің профилім";
$lang['add_photo'] = "Фотосурет қосу";

$lang['agreement'] = "Келісім";
$lang['command'] = "Ұжым";
$lang['footer_text'] = "Footer Text";
$lang['emailinuse'] = "Мұндай email қолданыста бар";
$lang['upgrade_browser'] = "РЎР°Р№С‚ РЅРµ СЂР°Р±РѕС‚Р°РµС‚ РєРѕСЂСЂРµРєС‚РЅРѕ РІ Р±СЂР°СѓР·РµСЂРµ РРЅС‚РµСЂРЅРµС‚ Р­РєСЃРїР»РѕСЂРµСЂ РІРµСЂСЃРёРё 6. <br> РћР±РЅРѕРІРёС‚Рµ СЃРІРѕР№ Р±СЂР°СѓР·РµСЂ РґРѕ Р±РѕР»РµРµ РІС‹СЃРѕРєРѕР№ РІРµСЂСЃРёРё РёР»Рё РёСЃРїРѕР»СЊР·СѓР№С‚Рµ Р±СЂР°СѓР·РµСЂС‹  Firefox, Opera, Safari, Chrome.";
$lang['error_heading'] = "Р’РѕР·РЅРёРєР»Р° РѕС€РёР±РєР°! ";

$lang['lot_of_photos'] = "Р—Р°РїСЂРµС‰РµРЅРѕ Р·Р°РіСЂСѓР¶Р°С‚СЊ Р±РѕР»РµРµ 5-С‚Рё С„РѕС‚Рѕ РЅР° РєРѕРЅРєСѓСЂСЃ! ";
$lang['erotic_banned'] = "Р¤РѕС‚Рѕ РёР· РґР°РЅРЅРѕР№ РєР°С‚РµРіРѕСЂРёРё СЂР°Р·СЂРµС€Р°РµС‚СЃСЏ РїСЂРѕСЃРјР°С‚СЂРёРІР°С‚СЊ С‚РѕР»СЊРєРѕ Р·Р°СЂРµРіРёСЃС‚СЂРёСЂРѕРІР°РЅРЅС‹Рј РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРј, РґРѕСЃС‚РёРіС€РёРј 18 Р»РµС‚";
$lang['upload_warn'] = "РРґРµС‚ Р·Р°РіСЂСѓР·РєР° С„РѕС‚Рѕ, РЅРµ РѕР±РЅРѕРІР»СЏР№С‚Рµ СЃС‚СЂР°РЅРёС†Сѓ РґРѕ Р·Р°РІРµСЂС€РµРЅРёСЏ Р·Р°РіСЂСѓР·РєРё!";
	$lang['comp_openall'] = "Р Р°СЃРєСЂС‹С‚СЊ РІСЃРµ";
	$lang['comp_closeall'] = "РЎРєСЂС‹С‚СЊ РІСЃРµ";

/*
$security_question[1] = "What is your 1st pet's name?";
$security_question[2] = "What is your favourite movie?";
$security_question[3] = "What is your favourite band?";
*/