<?php
$ci = &get_instance();
$admin_email = $ci->config->item('admin_email');
// Retrieve a config item named site_name contained within the blog_settings array
$site_title = $ci->config->item('site_name', 'blog_settings');

//$lang[''] = "";  //for copying

$lang['category'] = "Топтама";

$lang['cat_name_field'] = "Топтама атауы:";
$lang['cat_desc_field'] = "Топтама сипаттамасы:";
$lang['save'] = "Топтаманы сақтау";

$lang['error_data_saving'] = "Мәліметтерді сақтауда қателік бар. Кейінірек жіберіп көріңіз немесе $admin_email мекен-жайындағы сайт әкімшілігімен байланысыңыз";

/* End of file catalog_lang.php */
